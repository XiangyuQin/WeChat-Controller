﻿# -*- coding:utf-8 -*-
test_appmsg = {
    'author':'接口测试文章——作者',
    'title':'接口测试文章——标题',
    'sourceurl':'www.baidu.com',
    'cover':'/home/pythonDir/cover.jpg',
    'digest':'大部分人认为表白是跟女孩确定恋爱关系非常有效的一种方法，有耐心和妹子建立深层次的联系感并对妹子产生了吸引力，妹子接 ' \
    '受的概念就会大增其实，盲目的表白你会发现往往到最后没有任何效果。',
    'content':'<p style="line-height: 25.6px; white-space: normal;"><em><span style="word-wrap: break-word; font-weight: 700;">表白，'\
    '相信这个动作是每个人一生当中都会触发的一个行为，' \
    '大部分人认为表白是跟女孩确定恋爱关系非常有效的一种方法，有耐心和妹子建立深层次的联系感并对妹子产生了吸引力，妹子接 ' \
    '受的概念就会大增其实，盲目的表白你会发现往往到最后没有任何效果。</span></em></p><p style="line-height: 25.6px; white-spac' \
    'e: normal;"><span style="line-height: 1.6;">   有个朋友，做个一个实验，并把它录制成了一个视频剪辑，内容大概是这样的，他收集' \
    '了现实生活中将近50个男人的表白现场实录，有的是在人民广场这样人流量聚焦的地区，有的像电影里那样是在很有格调的西餐厅，有的是在酒吧，有的是在朋 ' \
    '友聚会，更有夸张一点的，你们可能都想不到，是在足球比赛的现场。</span></p><p style="line-height: 25.6px; white-space: normal;">最后的结果出来了，成功率几乎 '\
    '只有5%不到，对的，你没看错，就是这么低。很多兄弟觉得不可思议，怎么会这样，和电视电影里的完全不一样啊，呵呵，因为这才是现实。为什么女人的反应都几乎是拒绝，完全不顾及' \
    '男人的面子，也完全没有被感动的赶脚。</p><p style="line-height: 25.6px; white-space: normal;">那么我来告诉兄弟们，问题出在哪，因为这种情况下，女人会本能的产生一种压迫' \
    '感，或者说是不安全感，她们会条件反射式的去拒绝。</p><p style="line-height: 25.6px; white-space: normal;">因为在进化学来看，远古时代的人类基因，仍然在现代人的基因里有' \
    '保留，在古代的女人，她们一旦选定一个男人，她的生命就跟这个男人绑定在了一起，换句话说，如果这个男人不能提供足够的食物，这个女人在怀孕期间就会被饿死。</p><p style="lin' \
    'e-height: 25.6px; white-space: normal;">这种选错了对象就要付出生命代价的基因一直延续至今，所以，女人一旦面对男人表白这种事情的时候，就会自动切换到理性思考模式，接受面临的是风险，而拒绝是最' \
    '保险的做法，女人不傻，所以，她们会选择拒绝就不难理解了。<span style="line-height: 1.6;">现在兄弟们懂了这个道理，那有的兄弟要说了，既然这样，不去表白，怎么追到女人' \
    '，难道让女人对你表白么？恩，让女人表白也不是不可能的，我们家的方法就可以让你做到，让女人倒追你，我们有的是方法。</span></p><p style="line-height: 25.6px; white-s' \
    'pace: normal;">这就是我们家自主开发的男神模式，它可以让你和女人的互动交流之后，让女人喜欢上你，让女人主动对你示好，对你表白。至于该怎么做，只需要关注我们' \
    '的微信公众号，那里面有干货会告诉你。</p><p><br/></p>',
}
email = "xjmjyqxy@sina.com"
password = "b3ca2251f5f48978f9e9c32aeb5fde26"
msgType = {'text': 1, 'image': 2, 'audio': 3, 'news': 10, 'video': 15}

logSrc="logs/"
logMaxBytes=10*1024*1024
logBackupCount=5

imageSrc="/data/app/WebSite"