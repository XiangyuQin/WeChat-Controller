# -*- coding:utf-8 -*-
import datetime
from WeChatController import WeChatController
from MongoService import MongoService
from Log import Log

class Application(object):
    def __init__(self):
        self.now = datetime.datetime.now()
        self.log = Log(self.now)
        weChatController = WeChatController(logger=self.log)
        
    
    def SendMass(self):
        articles=self.getArticles("0", 1)
        appMsgs=self.generateMsgs(articles)
        weChatController.sendMass(appMsgs)
        

    def getArticles(self, type, limit):
        redisService = RedisService(self.log)
        mark = RedisService.getArticlesMark()
        service = MongoService(self.log)
        articles = service.getArticles("0", 1, mark)
        return articles
        
    def generateMsgs(self,articles):
        appMsgs=[]
        for article in articles:
            appMsg = self.generateMsg(article)
            appMsgs.append(appMsg)  
        return appMsgs
        
    def generateMsg(self, article):
        appMsg={}
        appMsg["author"] = article["writer"]
        appMsg["title"] = article["title"]
        appMsg["sourceurl"] = "www.baidu.com"
        appMsg["cover"] = config.imageSrc+article["image"]
        appMsg["digest"] = article["brief"]
        appMsg["content"] = article["content"]
        return appMsg
        
    def uploadImg(self):
        articles=self.getArticles("0", 1)
        appMsgs=self.generateMsgs(articles)
        print appMsgs
        #weChatController.uploadImg(appMsg)
        
    def uploadArticles(self):
        imgUrl=""
        weChatController.addAppmsg(imgUrl)
        pass
        
    